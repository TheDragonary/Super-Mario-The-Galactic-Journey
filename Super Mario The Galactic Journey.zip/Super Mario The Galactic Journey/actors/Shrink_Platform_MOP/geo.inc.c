const GeoLayout Shrink_Platform_MOP[]= {
GEO_SHADOW(10,0,262),
GEO_OPEN_NODE(),
GEO_ANIMATED_PART(1,0,6,0,DL_Shrink_Platform_MOP_0x3021220),
GEO_CLOSE_NODE(),
GEO_END(),
};
