#ifndef Shrink_Platform_MOP_Shrink_Platform_MOP_model_HEADER_H
#define Shrink_Platform_MOP_Shrink_Platform_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Shrink_Platform_MOP_0x3021130[];
extern const u8 Shrink_Platform_MOP__texture_03020930[];
extern const Light_t Light_Shrink_Platform_MOP_0x3020920;
extern const Ambient_t Light_Shrink_Platform_MOP_0x3020928;
extern const Gfx DL_Shrink_Platform_MOP_0x3021220[];
#endif