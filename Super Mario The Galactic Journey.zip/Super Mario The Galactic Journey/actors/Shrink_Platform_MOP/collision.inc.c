const Collision col_Shrink_Platform_MOP_0xad3720[] = {
COL_INIT(),
COL_VERTEX_INIT(4),
COL_VERTEX( 129, 6, 129),
COL_VERTEX( -129, 6, -129),
COL_VERTEX( -129, 6, 129),
COL_VERTEX( 129, 6, -129),
COL_TRI_INIT( 0, 2),
COL_TRI( 0, 1, 2),
COL_TRI( 1, 0, 3),
COL_TRI_STOP(),
COL_END(),
};
