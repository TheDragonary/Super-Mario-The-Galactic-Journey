#ifndef Flipswap_Platform_MOP_Flipswap_Platform_MOP_model_HEADER_H
#define Flipswap_Platform_MOP_Flipswap_Platform_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Flipswap_Platform_MOP_0x5f8f80[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f9070[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f9160[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f9250[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f9340[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f9430[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f9520[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f9610[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f9700[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f97f0[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f98e0[];
extern Vtx VB_Flipswap_Platform_MOP_0x5f99d0[];
extern u8 Flipswap_Platform_MOP__texture_005F8780[];
extern Light_t Light_Flipswap_Platform_MOP_0x5f8770;
extern Ambient_t Light_Flipswap_Platform_MOP_0x5f8778;
extern Gfx DL_Flipswap_Platform_MOP_0x5f9ac0[];
#endif