const GeoLayout Flipswap_Platform_MOP[] = {
   GEO_CULLING_RADIUS(300),
   GEO_OPEN_NODE(),
	  GEO_ANIMATED_PART(1, 0, 6, 0, DL_Flipswap_Platform_MOP_0x5f9ac0),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, DL_Flipswap_Platform_MOP_0x5f9ac0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
