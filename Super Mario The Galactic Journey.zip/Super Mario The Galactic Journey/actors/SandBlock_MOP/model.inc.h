#ifndef Sandblock_MOP_Sandblock_MOP_model_HEADER_H
#define Sandblock_MOP_Sandblock_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Sandblock_MOP_0x3021b54[];
extern Vtx VB_Sandblock_MOP_0x3021c44[];
extern Vtx VB_Sandblock_MOP_0x3021d34[];
extern Vtx VB_Sandblock_MOP_0x3021e24[];
extern Vtx VB_Sandblock_MOP_0x3021f14[];
extern Vtx VB_Sandblock_MOP_0x3022004[];
extern Vtx VB_Sandblock_MOP_0x30220f4[];
extern Vtx VB_Sandblock_MOP_0x30221e4[];
extern const u8 Sandblock_MOP__texture_03021354[];
extern const Light_t Light_Sandblock_MOP_0x3021344;
extern const Ambient_t Light_Sandblock_MOP_0x302134c;
extern const Gfx DL_Sandblock_MOP_0x30222d4[];
#endif