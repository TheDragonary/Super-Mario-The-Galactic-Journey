const GeoLayout Moving_Rotating_Block_MOP[]= {
GEO_CULLING_RADIUS(4000),
GEO_OPEN_NODE(),
GEO_SWITCH_CASE(2, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_Moving_Rotating_Block_MOP_0x603610),
GEO_DISPLAY_LIST(1,DL_Moving_Rotating_Block_MOP_0x603000),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
