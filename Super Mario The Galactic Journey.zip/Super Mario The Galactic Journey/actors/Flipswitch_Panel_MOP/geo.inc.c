const GeoLayout Flipswitch_Panel_MOP[]= {
GEO_CULLING_RADIUS(4000),
GEO_OPEN_NODE(),
GEO_SWITCH_CASE(3, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_Flipswitch_Panel_MOP_0x5fadd0),
GEO_DISPLAY_LIST(1,DL_Flipswitch_Panel_MOP_0x5fb0b0),
GEO_DISPLAY_LIST(1,DL_Flipswitch_Panel_MOP_0x5fb110),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
