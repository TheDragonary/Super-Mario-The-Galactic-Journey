const GeoLayout Flipswap_Platform_Border_MOP[] = {
   GEO_SHADOW(SHADOW_CIRCLE_4_VERTS, 0x98, 100),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, DL_Flipswap_Platform_Border_MOP_0x5f8560),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
