const GeoLayout Green_Switchboard_Gears_MOP[] = {
   GEO_SHADOW(SHADOW_CIRCLE_4_VERTS, 0x98, 100),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, DL_Green_Switchboard_Gears_MOP_0x600460),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
