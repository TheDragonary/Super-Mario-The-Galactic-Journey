#ifndef Checkpoint_Flag_MOP_Checkpoint_Flag_MOP_model_HEADER_H
#define Checkpoint_Flag_MOP_Checkpoint_Flag_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Checkpoint_Flag_MOP_0x605c10[];
extern Vtx VB_Checkpoint_Flag_MOP_0x605d00[];
extern Vtx VB_Checkpoint_Flag_MOP_0x605df0[];
extern Vtx VB_Checkpoint_Flag_MOP_0x605ee0[];
extern Vtx VB_Checkpoint_Flag_MOP_0x605fd0[];
extern Vtx VB_Checkpoint_Flag_MOP_0x6060c0[];
extern Vtx VB_Checkpoint_Flag_MOP_0x6061b0[];
extern Vtx VB_Checkpoint_Flag_MOP_0x6062a0[];
extern Vtx VB_Checkpoint_Flag_MOP_0x606390[];
extern Vtx VB_Checkpoint_Flag_MOP_0x606480[];
extern Vtx VB_Checkpoint_Flag_MOP_0x606570[];
extern u8 Checkpoint_Flag_MOP__texture_00604410[];
extern u8 Checkpoint_Flag_MOP__texture_00604C10[];
extern Light_t Light_Checkpoint_Flag_MOP_0x604400;
extern Ambient_t Light_Checkpoint_Flag_MOP_0x604408;
extern Gfx DL_Checkpoint_Flag_MOP_0x606660[];
#endif