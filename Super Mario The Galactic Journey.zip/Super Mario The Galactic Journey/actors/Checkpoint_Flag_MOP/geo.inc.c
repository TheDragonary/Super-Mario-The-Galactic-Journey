const GeoLayout Checkpoint_Flag_MOP[] = {
   GEO_SHADOW(SHADOW_CIRCLE_4_VERTS, 0x98, 100),
   GEO_OPEN_NODE(),
      GEO_SCALE(0x00, 65536),
      GEO_OPEN_NODE(),
		 GEO_DISPLAY_LIST(LAYER_OPAQUE, DL_Checkpoint_Flag_MOP_0x606660),
      GEO_CLOSE_NODE(),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
