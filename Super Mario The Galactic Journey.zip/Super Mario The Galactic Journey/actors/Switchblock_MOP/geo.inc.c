const GeoLayout Switchblock_MOP[]= {
GEO_SWITCH_CASE(4, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_Switchblock_MOP_0x5f2e20),
GEO_DISPLAY_LIST(1,DL_Switchblock_MOP_0x5f5790),
GEO_DISPLAY_LIST(1,DL_Switchblock_MOP_0x5f3220),
GEO_DISPLAY_LIST(1,DL_Switchblock_MOP_0x5f5df0),
GEO_CLOSE_NODE(),
GEO_END(),
};
