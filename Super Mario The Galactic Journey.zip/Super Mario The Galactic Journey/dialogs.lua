smlua_text_utils_dialog_replace(DIALOG_000,1,6,30,200, (""))

smlua_text_utils_dialog_replace(DIALOG_001,1,4,95,200, ("Oh, hi there...\
I think this Monty\
Mole is hiding\
something. I wanted to\
check it out, but he's\
a bully... He would\
throw me into the toxic\
matter!!!\
If you can get rid of\
him somehow, you can\
look around to see what\
he might be hiding!"))

smlua_text_utils_dialog_replace(DIALOG_002,1,4,95,200, ("Hey, you! It's dangerous\
ahead, so listen up! Take\
my advice.\
\
Cross the two\
bridges ahead, then\
watch for falling\
water bombs.\
The Big Bob-omb at the\
top of the mountain is\
very powerful--don't let\
him grab you!\
We're Bob-omb Buddies,\
and we're on your side.\
You can talk to us\
whenever you'd like to!"))

smlua_text_utils_dialog_replace(DIALOG_003,1,5,95,200, ("Thank you, Mario! The Big\
Bob-omb is nothing but a\
big dud now! But the\
battle for the castle has\
just begun.\
Other enemies are holding\
the other Power Stars. If\
you recover more Stars,\
you can open new doors\
that lead to new worlds!\
My Bob-omb Buddies are\
waiting for you. Be sure\
to talk to them--they'll\
set up cannons for you."))

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, ("We're peace-loving\
Bob-ombs, so we don't use\
cannons.\
But if you'd like\
to blast off, we don't\
mind. Help yourself.\
We'll prepare all of the\
cannons in this course for\
you to use. Bon Voyage!"))

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, ("Hey, Mario! Is it true\
that you beat the Big\
Bob-omb? Cool!\
You must be strong. And\
pretty fast. So, how fast\
are you, anyway?\
Fast enough to beat me...\
Koopa the Quick? I don't\
think so. Just try me.\
How about a race to the\
mountaintop, where the\
Big Bob-omb was?\
Whaddya say? When I say\
『Go,』 let the race begin!\
\
Ready....\
\
//Go!////Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_006,1,3,30,200, ("Hey!!! Don't try to scam\
ME. You've gotta run\
the whole course.\
Later. Look me up when\
you want to race for\
real."))

smlua_text_utils_dialog_replace(DIALOG_007,1,5,30,200, ("Hufff...fff...pufff...\
Whoa! You...really...are...\
fast! A human blur!\
Here you go--you've won\
it, fair and square!"))

smlua_text_utils_dialog_replace(DIALOG_008,1,4,30,200, ("Hi. I am a friend\
of parko. I work with\
him, actually.\
I am interested in\
the legend of the\
Great Labyrinth.\
It was a punishment\
zone for mischiefs.\
It had a teleportation\
warp that is only a one\
way warp. I wonder...\
It is said that the\
teleportation warp\
is on a temple\
part.\
Hmmm... I wonder\
where?..."))

smlua_text_utils_dialog_replace(DIALOG_009,1,5,30,200, ("Long time, no see! Wow,\
have you gotten fast!\
Have you been training\
on the sly, or is it the\
power of the Stars?\
I've been feeling down\
about losing the last\
race. This is my home\
course--how about a\
rematch?\
The goal is in\
Windswept Valley.\
Ready?\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("You've stepped on the\
Wing Cap Switch. Wearing\
the Wing Cap, you can\
soar through the sky.\
Now Wing Caps will pop\
out of all the red blocks\
you find.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_011,1,4,30,200, ("You've just stepped on\
the Metal Cap Switch!\
The Metal Cap makes\
Mario invincible.\
Now Metal Caps will\
pop out of all of the\
green blocks you find.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, ("You've just stepped on\
the Vanish Cap Switch.\
The Vanish Cap makes\
Mario disappear.\
Now Vanish Caps will pop\
from all of the blue\
blocks you find.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, ("You've collected 100\
coins!\
Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("Wow! Another Silver Star!\
Do you want to Save?\
\
//You Bet//Not Now"))

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("You can punch enemies to\
knock them down. Press [A]\
to jump, [B] to punch.\
Press [A] then [B] to Kick.\
To pick something up,\
press [B], too. To throw\
something you're holding,\
press [B] again."))

smlua_text_utils_dialog_replace(DIALOG_016,1,3,30,200, ("Hop on the shiny shell and\
ride wherever you want to\
go! Shred those enemies!"))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("Mwa ha ha ha ha ha!!!\
It's been a while\
since we last met,\
Mario! I still remember\
our last encounter in\
Star Palace on planet\
Stardust!\
So you are here to stop\
my master plan, huh?!\
I must admit... This was\
Bowser's plan... But\
I took Bowser\
down and stole his master\
plan! To think I was his\
follower... What a puny\
wimp he turned out to be!\
Ha!\
Enough chat, Mario!\
You have come to restore\
the Galactic Star to its\
altar and spoil my plans?\
You don't stand a chance\
against me this time!\
But I know that you want\
to fight to save\
the day... So, I guess\
I can go along with it\
and finish you once\
and for all!\
Let's Rumble!!!"))

smlua_text_utils_dialog_replace(DIALOG_018,1,4,30,200, ("I'm sleeping because...\
...I'm sleepy. I don't\
like being disturbed.\
Please walk quietly."))

smlua_text_utils_dialog_replace(DIALOG_019,1,2,30,200, ("Mario, you made it here!\
I came to investigate\
with some Toads of the\
crew.\
This is an ancient valley\
as the fellow told me.\
It has a legend of a\
secret magic switch to\
the legendary metal cap.\
How about you find that\
switch? Maybe you can find\
a power star as well...\
Good luck."))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, ("Dear Mario:\
Please come to the\
castle. I've baked\
a cake for you.\
Yours truly--\
Princess Toadstool"))

smlua_text_utils_dialog_replace(DIALOG_021,1,5,95,200, ("  "))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,95,200, ("You can't open this door\
yet!"))

smlua_text_utils_dialog_replace(DIALOG_023,1,3,95,200, ("This key doesn't fit!"))

smlua_text_utils_dialog_replace(DIALOG_024,1,5,95,200, ("You need Star power to\
open this door. Recover a\
Power Star from an enemy\
inside one of the castle's\
paintings."))

smlua_text_utils_dialog_replace(DIALOG_025,1,4,95,200, ("It takes the power of\
3 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_026,1,4,95,200, ("It takes the power of\
8 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_027,1,4,95,200, ("It takes the power of\
30 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_028,1,4,95,200, ("It takes the power of\
50 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_029,1,5,95,200, ("To open the door that\
leads to the 『endless』\
stairs, you need 70\
Stars.\
Bwa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_030,1,6,30,200, ("Hello! The Lakitu Bros.,\
cutting in with a live\
update on Mario's\
progress. He's about to\
learn a technique for\
sneaking up on enemies.\
The trick is this: He has\
to walk very slowly in\
order to walk quietly.\
\
\
\
And wrapping up filming\
techniques reported on\
earlier, you can take a\
look around using [C]> and\
[C]<. Press [C]| to view the\
action from a distance.\
When you can't move the\
camera any farther, the\
buzzer will sound. This is\
the Lakitu Bros.,\
signing off."))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, ("No way! You beat me...\
again!! And I just spent\
my entire savings on\
these new Koopa\
Mach 1 Sprint shoes!\
Here, I guess I have to\
hand over this Star to\
the winner of the race.\
Congrats, Mario!"))

smlua_text_utils_dialog_replace(DIALOG_032,1,5,30,200, ("Well, Mario...\
This is as far as\
the Starship goes.\
You should be able\
to carry on from here\
and explore the vast\
space areas to gather\
the Silver Stars.\
Good luck!"))

smlua_text_utils_dialog_replace(DIALOG_033,1,6,30,200, ("It is said under a tree,\
You stand and you'll see.\
Close to me\
Is the field of\
The Crown Statue.\
But Out of the field\
I be\
Find me and the way\
you shall see..."))

smlua_text_utils_dialog_replace(DIALOG_034,1,6,30,200, ("This here is an ancient\
valley that was a land to\
the ancient\
civilization the Apotos.\
The major thing here is\
the legend of the metal\
cap. It is a metallic cap\
of great power, and\
green blocks hold it.\
You may have seen green\
blocks in some areas.\
They are not solid.\
\
You see... The Apotos,\
around 10000 years ago, \
they deactivated the\
metal caps with a switch.\
And they hid the\
switch somewhere unknown\
in this valley. They\
did that when they\
discovered that someone\
wanted to use the power\
for evil deeds. They\
deactivated the metal\
caps to avoid falling\
into dastardly hands.\
\
Legend has it that the\
switch is well protected\
by danger in its hiding\
place. If you're gonna\
try to find it, I warn\
you. It is really\
dangerous! That is, if\
you find its hiding place."))

smlua_text_utils_dialog_replace(DIALOG_035,1,5,30,200, ("There are four camera, or\
『[C],』 Buttons. Press [C]^\
to look around using the\
Control Stick.\
\
You'll usually see Mario\
through Lakitu's camera.\
It is the camera\
recommended for normal\
play.\
You can change angles by\
pressing [C]>. If you press\
[R], the view switches to\
Mario's camera, which\
is directly behind him.\
Press [R] again to return\
to Lakitu's camera. Press\
[C]| to see Mario from\
afar, using either\
Lakitu's or Mario's view."))

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, ("OBSERVATION PLATFORM\
Press [C]^ to take a look\
around. Don't miss\
anything!\
\
Press [R] to switch to\
Mario's camera. It\
always follows Mario.\
Press [R] again to switch\
to Lakitu's camera.\
Pause the game and\
switch the mode to 『fix』\
the camera in place while\
holding [R]. Give it a try!"))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, ("I win! You lose!\
Ha ha ha ha!\
You're no slouch, but I'm\
a better sledder!\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_038,1,3,95,200, ("Reacting to the Star\
power, the door slowly\
opens."))

smlua_text_utils_dialog_replace(DIALOG_039,1,4,30,200, ("Why hello there, friend!\
My name is Parko.\
I am an archaeologist\
interested in these\
ruins. This used to be\
the lands of\
the Refities tribe.\
It is said that those\
are among the very\
first civilizations\
in the universe!\
The kingdom used to\
be huge... Doesn't\
look like it, right?\
Truth is... The\
land here is barely 55\
percent of the entire\
land back then based\
on studying the ancient\
maps. It is likely that\
the rest of the land\
disappeared due to being\
destroyed by\
space phenomena."))

smlua_text_utils_dialog_replace(DIALOG_040,1,3,30,200, ("Warning!\
Cold, Cold Crevasse\
Below!"))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, ("I win! You lose!\
Ha ha ha!\
\
That's what you get for\
messin' with Koopa the\
Quick.\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_042,1,4,30,200, ("Howdy, partner!\
Welcome to the valley\
of the Twin Mountains.\
It's a beautiful valley...\
But sadly, these bad\
guys took over recently\
making this area\
dangerous...\
I used to take nice\
walks around\
the valley...\
But now, these\
baddies are around..."))

smlua_text_utils_dialog_replace(DIALOG_043,1,5,30,200, ("Dear Lakitus and\
Goomba troops in\
Sky Temple Lands.\
\
Reminder for the\
guards of the big tree.\
Make sure you keep\
the secret there safe.\
\
And Goombas by the big\
tree...\
If Mario makes it\
in the center\
of the coin ring,\
don't be dumb enough\
to attack! We don't\
want Mario to jump\
in the center of\
the coin ring by\
the big tree to dodge\
you now, do we?"))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, ("Whooo's there? Whooo\
woke me up? It's still\
daylight--I should be\
sleeping!\
\
Hey, as long as I'm\
awake, why not take a\
short flight with me?\
Press and hold [A] to grab\
on. Release [A] to let go.\
I'll take you wherever\
you want to go, as long\
as my wings hold out.\
Watch my shadow, and\
grab on."))

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, ("Whew! I'm just about\
flapped out. You should\
lay off the pasta, Mario!\
That's it for now. Press\
[A] to let go. Okay,\
bye byyyyyyeeee!"))

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, ("Hey Mario!\
The portal to this\
area just opened\
in front of my own\
eyes! I was scared to\
enter!\
Now if I am not\
mistaken, this is\
the Lost Galaxy!\
This here is one of\
the universe's\
greaatest mysteries!\
This galaxy holding\
an entire kingdom,\
was absorbed by a black\
hole kind of warp\
and it was lost with\
no clue to itswhere-\
abouts... The force\
is said to have\
displaced the kingdom\
elements of it to \
different locations than\
their original location\
with respect to\
the galaxy itself!\
I wonder if you can\
find the lost kingdom\
and explore this\
further... I guess you\
will do so for Silver\
Stars, at least..."))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("Hi! I'll prepare the\
cannon for you!"))

smlua_text_utils_dialog_replace(DIALOG_048,1,4,30,200, ("Snow Mountain Summit\
Watch for slippery\
conditions! Please enter\
the cottage first."))

smlua_text_utils_dialog_replace(DIALOG_049,1,5,30,200, ("Hi. Aren't you\
the famous Super Mario?\
Nice to meet you!\
I've over heard some\
baddies talking.\
They said there is\
a secret entrance\
to a place called\
Boiling Lave Towers\
somewhere here.\
They mentioned\
the entrance being\
a warp pipe on Lava."))

smlua_text_utils_dialog_replace(DIALOG_050,1,4,30,200, ("Hey there, mate!\
Have you ever heard\
of the legendary\
Rainbow Road?\
Many believe it exists!\
Ain't it exciting to\
know such a magnificent\
place exists?!\
I heard there exists\
a Rainbow Warp that\
leads there somehwhere\
around here!\
I would surely go there\
if I knew where this\
Rainbow Warp was!"))

smlua_text_utils_dialog_replace(DIALOG_051,1,6,30,200, ("Well hello again, mate!\
It seems that those nasty\
enemies have installed\
some kind of switches\
around... They may\
have built them\
as a start of building\
some home base for them.\
This would be real bad,\
mate... The switches\
seem to be powering up \
some plan they seem to\
have...\
I wonder if stepping on\
the switches will foil\
whatever their evil plot\
might be..."))

smlua_text_utils_dialog_replace(DIALOG_052,1,5,30,200, ("Stop and press [Z] to\
crouch, then press [A]\
to do a high, Backward\
Somersault!\
\
To perform a Side\
Somersault, run, do a\
sharp U-turn and jump.\
You can catch lots of\
air with both jumps."))

smlua_text_utils_dialog_replace(DIALOG_053,1,5,30,200, ("Sometimes, if you pass\
through a coin ring or\
find a secret point in a\
course, a red number will\
appear.\
If you trigger five red\
numbers, a secret Star\
will show up."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("Welcome to the snow\
slide! Hop on! To speed\
up, press forward on the\
Control Stick. To slow\
down, pull back."))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, ("Hey-ey, Mario, buddy,\
howzit goin'? Step right\
up. You look like a fast\
sleddin' kind of guy.\
I know speed when I see\
it, yes siree--I'm the\
world champion sledder,\
you know. Whaddya say?\
How about a race?\
Ready...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, ("You brrrr-oke my record!\
Unbelievable! I knew\
that you were the coolest.\
Now you've proven\
that you're also the\
fastest!\
I can't award you a gold\
medal, but here, take this\
Star instead. You've\
earned it!"))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("Egad! My baby!! Have you\
seen my baby??? She's\
the most precious baby in\
the whole wide world.\
(They say she has my\
beak...) I just can't\
remember where I left\
her.\
Let's see...I stopped\
for herring and ice cubes,\
then I...oohh! I just\
don't know!"))

smlua_text_utils_dialog_replace(DIALOG_058,1,4,30,200, ("You found my precious,\
precious baby! Where\
have you been? How can\
I ever thank you, Mario?\
Oh, I do have this...\
...Star. Here, take it\
with my eternal\
gratitude."))

smlua_text_utils_dialog_replace(DIALOG_059,1,4,30,200, ("That's not my baby! She\
looks nothing like me!\
Her parents must be\
worried sick!"))

smlua_text_utils_dialog_replace(DIALOG_060,1,4,30,200, ("ATTENTION!\
Read Before Diving In!\
\
\
If you stay under the\
water for too long, you'll\
run out of oxygen.\
\
Return to the surface for\
air or find an air bubble\
or coins to breathe while\
underwater.\
Press [A] to swim. Hold [A]\
to swim slow and steady.\
Tap [A] with smooth timing\
to gain speed.\
Press Up on the\
Control Stick and press [A]\
to dive.\
\
Press Down on the Control\
Stick and press [A] to\
return to the surface.\
\
Hold Down and press [A]\
while on the surface near\
the edge of the water to\
jump out."))

smlua_text_utils_dialog_replace(DIALOG_061,1,4,30,200, ("BRRR! Frostbite Danger!\
Do not swim here.\
I'm serious.\
/--The Penguin"))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("Hidden inside the green\
block is the amazing\
Metal Cap.\
Wearing it, you won't\
catch fire or be hurt\
by enemy attacks.\
You don't even have to\
breathe while wearing it.\
\
The only problem:\
You can't swim in it."))

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, ("In this block is\
the vanish cap.\
You can use it\
to go through some\
cages or so...\
If it is not solid,\
probably you did not\
activate it yet.\
\
It is said there is\
a magic warp leading to\
the area that has\
the cap switches\
hidden in these fields.\
It is also said that\
the magic warp is\
a hole...\
"))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("When you put on the Wing\
Cap that comes from a\
red block, do the Triple\
Jump to soar high into\
the sky.\
Use the Control Stick to\
guide Mario. Pull back to\
to fly up, press forward\
to nose down, and press [Z]\
to land."))

smlua_text_utils_dialog_replace(DIALOG_065,1,6,30,200, ("Oh, hello Mario...\
This door is locked!\
If you don't have\
the key for it, you\
can't go any further.\
If you didn't get\
the key, then you\
should go search fot it.\
It must be in the hands\
of one of Bowser's\
dastardly followers!\
But I wonder where..."))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, ("Mario, it's Peach!\
Please be careful! Bowser\
is so wicked! He will try\
to burn you with his\
horrible flame breath.\
Run around behind and\
grab him by the tail with\
the [B] Button. Once you\
grab hold, swing him\
around in great circles.\
Rotate the Control Stick\
to go faster and faster.\
The faster you swing him,\
the farther he'll fly.\
\
Use the [C] Buttons to look\
around, Mario. You have\
to throw Bowser into one\
of the bombs in the four\
corners.\
Aim well, then press [B]\
again to launch Bowser.\
Good luck, Mario! Our\
fate is in your hands."))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("Tough luck, Mario!\
Princess Toadstool isn't\
here...Gwa ha ha!! Go\
ahead--just try to grab\
me by the tail!\
You'll never be able to\
swing ME around! A wimp\
like you won't throw me\
out of here! Never! Ha!"))

smlua_text_utils_dialog_replace(DIALOG_068,1,5,30,200, ("Hey Mario... A Luma just\
built this cannon to\
send you to an area\
that may have Silver\
Stars... But he left\
without saying where!\
However, based on\
Captain Toad's judgement,\
planet Stardust is\
somewhere over there.\
Curious since you had\
an adventure there\
a few years back...\
Might you actually\
visit an area in planet\
Stardust again?\
"))

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, ("Sometimes you'll bump into\
invisible walls at the\
edges of the painting\
worlds. If you hit a wall\
while flying, you'll bounce\
back."))

smlua_text_utils_dialog_replace(DIALOG_070,1,5,30,200, ("You can return to the\
castle's main hall at any\
time from the painting\
worlds where the enemies\
live.\
Just stop, stand still,\
press Start to pause the\
game, then select\
『Exit Course.』\
\
You don't have to collect\
all Power Stars in one\
course before going on to\
the next.\
\
Return later, when you're\
more experienced, to pick\
up difficult ones.\
\
\
Whenever you find a Star,\
a hint for finding the\
next one will appear on\
the course's start screen.\
\
You can, however, collect\
any of the remaining\
Stars next. You don't\
have to recover the one\
described by the hint."))

smlua_text_utils_dialog_replace(DIALOG_071,1,3,30,200, ("Mario! Look at this\
place! The Rainbow trees,\
the Galactic Star's\
altar, the stardust...\
It's Beautiful!\
This place looks\
like something taken out\
of a dream!"))

smlua_text_utils_dialog_replace(DIALOG_072,1,5,30,200, ("High winds ahead!\
Pull your Cap down tight.\
If it blows off, you'll\
have to find it on this\
mountain."))

smlua_text_utils_dialog_replace(DIALOG_073,1,4,95,200, ("Aarrgh! Ahoy, matey. I\
have sunken treasure,\
here, I do.\
\
But to pluck the plunder,\
you must open the\
Treasure Chests in the\
right order.\
What order is that,\
ye say?\
\
\
I'll never tell!\
\
//--The Cap'n"))

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, ("Well, hello!\
I come here quite\
often... I know\
it's not safe right\
now, but I love this\
area.\
However, as I entered\
this cave now, I started\
feeling a lot of Star\
energy!\
Is it possible that\
there is a Star\
around here?!\
Hmmm..."))

smlua_text_utils_dialog_replace(DIALOG_075,1,5,30,200, ("Mario!! My castle is in\
great peril. I know that\
Bowser is the cause...and\
I know that only you can\
stop him!\
The doors in the castle\
that have been sealed by\
Bowser can be opened only\
with Star Power.\
\
But there are secret\
paths in the castle,\
paths that Bowser hasn't\
found.\
\
One of those paths is in\
this room, and it holds\
one of the castle's Secret\
Stars!\
\
Find that Secret Star,\
Mario! It will help you\
on your quest. Please,\
Mario, you have to\
help us!\
Retrieve all of the\
Power Stars in the castle\
and free us from this\
awful prison!\
Please!"))

smlua_text_utils_dialog_replace(DIALOG_076,1,6,30,200, ("Hi Mario...\
Guess who I just saw!\
Bowser!\
He passed by here.\
At first I was shaken in\
fear and panic...\
But then Bowser said\
that he is coming\
in peace. He told me\
one of his followers\
betrayed him and\
stole his master plan!\
\
Oh yeah, before I\
forget...\
He gave me a Silver Star\
to give to you, Mario!"))

smlua_text_utils_dialog_replace(DIALOG_077,1,2,150,200, ("It is decreed that one\
shall pound the pillars."))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("Well, Mario you did it!\
Another heroic journey\
comes to a victorious\
end for you!\
Congratulations...\
To us all that is...\
I gotta say... This\
place is awesome! Too bad\
the Captain didn't\
get a chance to see it!\
He dropped us here and\
he's gonna pick us up\
soon."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, ("Owwwuu! Let me go!\
Uukee-kee! I was only\
teasing! Can't you take\
a joke?\
I'll tell you what, let's\
trade. If you let me go,\
I'll give you something\
really good.\
So, how about it?\
\
//Free him/ Hold on"))

smlua_text_utils_dialog_replace(DIALOG_080,1,1,30,200, ("Eeeh hee hee hee!"))

smlua_text_utils_dialog_replace(DIALOG_081,1,4,30,200, ("Wow, Mario! You did it!\
You restored the Galactic\
Star to its Altar!\
You saved the universe\
from disaster yet again!\
Thank you so much!\
The universe thanks\
you!\
Hey, there seems\
to be a Silver Star up on\
the altar. I think\
you should take it."))

smlua_text_utils_dialog_replace(DIALOG_082,1,4,30,200, ("Mario! Something freaky\
just happened!!!\
Just a moment ago,\
this portal appeared\
right in front of my\
eyes!!!\
I was shocked!\
However, our Toad friend\
was actually daring!\
He jumped into the portal!\
Such confidence he had!!!\
I wonder if he's ok...\
Maybe you should go after\
him, Mario. Besides...\
you may need to go in\
to search for Silver Stars\
anyway...\
\
\
Oh yeah... I just\
remembered. This Silver\
Star jumped out of\
the portal... I managed\
catching it... I guess\
it's best you take it,\
Mario!"))

smlua_text_utils_dialog_replace(DIALOG_083,1,6,30,200, ("Hey Mario!\
How's it going?\
This place is crawling\
with baddies. That's\
for sure...\
By the way...\
Guess what I just\
found! A Silver Star!\
Go on and take it,\
Mario!"))

smlua_text_utils_dialog_replace(DIALOG_084,1,3,30,200, ("Hey! What's the big\
idea?\
This Star? Hey that's\
been given to me to\
keep it safe! You can't\
have it!\
I won't....\
Ouch! Fine. Take it!\
Just let me go!!!"))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("You don't stand a ghost\
of a chance in this house.\
If you walk out of here,\
you deserve...\
...a Ghoul Medal..."))

smlua_text_utils_dialog_replace(DIALOG_086,1,3,30,200, ("Running around in circles\
makes some bad guys roll\
their eyes."))

smlua_text_utils_dialog_replace(DIALOG_087,1,4,30,200, ("Santa Claus isn't the only\
one who can go down a\
chimney! Come on in!\
/--Cabin Proprietor"))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("Work Elevator\
For those who get off\
here: Grab the pole to the\
left and slide carefully\
down."))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,95,200, ("Both ways fraught with\
danger! Watch your feet!\
Those who can't do the\
Long Jump, tsk, tsk. Make\
your way to the right.\
Right: Work Elevator\
/// Cloudy Maze\
Left: Black Hole\
///Underground Lake\
\
Red Circle: Elevator 2\
//// Underground Lake\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_090,1,6,30,200, ("Bwa ha ha ha!\
You've stepped right into\
my trap, just as I knew\
you would! I warn you,\
『Friend,』 watch your\
step!"))

smlua_text_utils_dialog_replace(DIALOG_091,2,2,30,200, ("Danger!\
Strong Gusts!\
But the wind makes a\
comfy ride."))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("Hey! How dare you\
intrude in here?\
Who gave you\
permission to storm\
my Aquatic Castle?\
I, Master Snufit, will\
not approve of this\
behaviour! You should\
know better than to\
tres-pass here!\
Now prepare to meet\
your fate!"))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("Mario! You again! Well\
that's just fine--I've\
been looking for something\
to fry with my fire\
breath!\
Your Star Power is\
useless against me!\
Your friends are all\
trapped within the\
walls...\
And you'll never see the\
Princess again!\
Bwa ha ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, ("Get a good run up the\
slope! Do you remember\
the Long Jump? Run, press\
[Z], then jump!"))

smlua_text_utils_dialog_replace(DIALOG_095,1,4,30,200, ("About the springs\
in this game:\
\
In this game, when\
using the bounce\
springs, it is\
recommended to hold\
the direction pad\
in the direction the\
spring launches you\
so that you can reach\
the desired destination.\
\
For the spring here,\
you will need to control\
the direction pad\
as needed to land at\
a point you can\
climb to the top."))

smlua_text_utils_dialog_replace(DIALOG_096,1,4,30,200, ("The path is narrow here.\
Easy does it! No one is\
allowed on top of the\
mountain!\
And if you know what's\
good for you, you won't\
wake anyone who's\
sleeping!\
Move slowly,\
tread lightly."))

smlua_text_utils_dialog_replace(DIALOG_097,1,5,30,200, ("Don't be a pushover!\
If anyone tries to shove\
you around, push back!\
It's one-on-one, with a\
fiery finish for the loser!"))

smlua_text_utils_dialog_replace(DIALOG_098,1,2,95,200, ("Come on in here...\
...heh, heh, heh..."))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("Eh he he...\
You're mine, now, hee hee!\
I'll pass right through\
this wall. Can you do\
that? Heh, heh, heh!"))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("Ukkiki...Wakkiki...kee kee!\
Ha! I snagged it!\
It's mine! Heeheeheeee!"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, ("Ackk! Let...go...\
You're...choking...me...\
Cough...I've been framed!\
This Cap? Oh, all right,\
take it. It's a cool Cap,\
but I'll give it back.\
I think it looks better on\
me than it does on you,\
though! Eeeee! Kee keee!"))

smlua_text_utils_dialog_replace(DIALOG_102,1,5,30,200, ("Pssst! The Boos are super\
shy. If you look them\
in the eyes, they fade\
away, but if you turn\
your back, they reappear.\
It's no use trying to hit\
them when they're fading\
away. Instead, sneak up\
behind them and punch."))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("Upon four towers\
one must alight...\
Then at the peak\
shall shine the light..."))

smlua_text_utils_dialog_replace(DIALOG_104,1,5,30,200, ("The shadowy star in front\
of you is a 『Star\
Marker.』 When you collect\
all 8 Red Coins, the Star\
will appear here."))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!\
\
You can reach the Star on\
the floating island by\
using the four cannons.\
Use the Control Stick to\
aim, then press [A] to fire.\
\
If you're handy, you can\
grab on to trees or poles\
to land."))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!"))

smlua_text_utils_dialog_replace(DIALOG_107,1,3,95,200, ("You... Can't...\
Kill... Ghosts...\
We... Always...\
Rise... Again..."))

smlua_text_utils_dialog_replace(DIALOG_108,1,2,95,200, ("Who dares intrude\
this castle?\
Who dares mess\
with the Boos?!\
You have written\
your death date!\
Prepare to meet your\
doom!\
He he he he he!!!"))

smlua_text_utils_dialog_replace(DIALOG_109,1,4,95,200, ("Ooooo Nooooo!\
Talk about out-of-body\
experiences--my body\
has melted away!\
Have you run in to any\
headhunters lately??\
I could sure use a new\
body!\
Brrr! My face might\
freeze like this!"))

smlua_text_utils_dialog_replace(DIALOG_110,1,5,95,200, ("I need a good head on my\
shoulders. Do you know of\
anybody in need of a good\
body? Please! I'll follow\
you if you do!"))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("Perfect! What a great\
new body! Here--this is a\
present for you. It's sure\
to warm you up."))

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, ("Collect as many coins as\
possible! They'll refill\
your Power Meter.\
\
You can check to see how\
many coins you've\
collected in each of the\
15 enemy worlds.\
You can also recover\
power by touching the\
Spinning Heart.\
\
The faster you run\
through the heart, the\
more power you'll recover."))

smlua_text_utils_dialog_replace(DIALOG_113,1,6,30,200, ("There are special Caps in\
the red, green and blue\
blocks. Step on the\
switches in the hidden\
courses to activate the\
Cap Blocks."))

smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, ("So, you are still\
traveling through\
space to stop Bowser,\
huh?!\
You never change do\
you?\
Now I plan to make\
you reconsider, Mario!"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, ("Grrr-umble...\
Defeated again!\
You'll pay for this,\
Mario! I swear, there\
will come a day you\
shall fall!"))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("Ouch... No...\
Can it be my destiny\
that again you defeat\
me?!\
All my efforts... All\
my dreams... All my\
power... Gone!\
I can't believe it!\
I failed again!\
Hmmm... I guess you won\
this time, Mario.\
But one day, I'll get my\
revenge! One day I WILL\
defeat you!\
As for now...\
Farewell..."))

smlua_text_utils_dialog_replace(DIALOG_117,1,1,95,200, ("Who dares disturb our\
sleep?!\
We are the Mummy Stone\
Brothers.\
We are the guardians\
of these ancient grounds.\
You are not allowed to\
enter the sacred grounds!\
You shall pay!"))

smlua_text_utils_dialog_replace(DIALOG_118,1,6,95,200, ("Noooo... Impossible!\
How could it be?!\
We have been defeated\
by a pest like you?!\
Hmm... You are\
strong... No doubt\
about it.\
Take this Silver Star.\
Farewell.."))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, ("Grrr! I was a bit\
careless. This is not as I\
had planned...but I still\
hold the power of the\
Stars, and I still have\
Peach.\
Bwa ha ha! You'll get no\
more Stars from me! I'm\
not finished with you yet,\
but I'll let you go for\
now. You'll pay for this...\
later!"))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, ("Ooowaah! Ouch!\
You're a tough one!\
I was expecting to\
fry you easily!\
Gah... I can't\
believe you beat me!\
I'm furious just\
thinking of it!"))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("Nooo! It can't be!\
You've really beaten me,\
Mario?!! I gave those\
troops power, but now\
it's fading away!\
Arrgghh! I can see peace\
returning to the world! I\
can't stand it! Hmmm...\
It's not over yet...\
\
C'mon troops! Let's watch\
the ending together!\
Bwa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("The Black Hole\
Right: Work Elevator\
/// Cloudy Maze\
Left: Underground Lake"))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("Metal Cavern\
Right: To Waterfall\
Left: Metal Cap Switch"))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("Work Elevator\
Danger!!\
Read instructions\
thoroughly!\
Elevator continues in the\
direction of the arrow\
activated."))

smlua_text_utils_dialog_replace(DIALOG_125,1,3,30,200, ("Hazy Maze-Exit\
Danger! Closed.\
Turn back now."))

smlua_text_utils_dialog_replace(DIALOG_126,2,3,30,200, ("Up: Black Hole\
Right: Work Elevator\
/// Hazy Maze"))

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, ("Underground Lake\
Right: Metal Cave\
Left: Abandoned Mine\
///(Closed)\
A gentle sea dragon lives\
here. Pound on his back to\
make him lower his head.\
Don't become his lunch."))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("Mwa ha ha...\
Fool! I am immune to\
dark matter! It can't\
drown me! And it is quite\
soft so it won't hurt me!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,5,30,200, ("Welcome to the Vanish\
Cap Switch Course! All of\
the blue blocks you find\
will become solid once you\
step on the Cap Switch.\
You'll disappear when you\
put on the Vanish Cap, so\
you'll be able to elude\
enemies and walk through\
many things. Try it out!"))

smlua_text_utils_dialog_replace(DIALOG_130,1,5,30,200, ("Welcome to the Metal Cap\
Switch Course! Once you\
step on the Cap Switch,\
the green blocks will\
become solid.\
When you turn your body\
into metal with the Metal\
Cap, you can walk\
underwater! Try it!"))

smlua_text_utils_dialog_replace(DIALOG_131,1,5,30,200, ("Welcome to the Wing Cap\
Course! Step on the red\
switch at the top of the\
tower, in the center of\
the rainbow ring.\
When you trigger the\
switch, all of the red\
blocks you find will\
become solid.\
\
Try out the Wing Cap! Do\
the Triple Jump to take\
off and press [Z] to land.\
\
\
Pull back on the Control\
Stick to go up and push\
forward to nose down,\
just as you would when\
flying an airplane."))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, ("Whoa, Mario, pal, you\
aren't trying to cheat,\
are you? Shortcuts aren't\
allowed.\
Now, I know that you\
know better. You're\
disqualified! Next time,\
play fair!"))

smlua_text_utils_dialog_replace(DIALOG_133,1,6,30,200, ("Welcome to the Starship\
Observatory Mario!\
The Lumas have built\
this ship for us so\
that we can use it\
for the space quest\
to help save the\
universe...\
The captain wants\
to explain to\
you the situation.\
"))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("This is the engine\
room...\
Right now, we have\
reached as far as we\
can. We were lucky to\
catch a Silver Star\
before it zoomed\
away...\
It gave us the\
energy to travel this\
far.\
If you want to\
set out to adventure\
and seek Silver Stars,\
use the teleportation\
pod over there in the\
back of the ship.\
A Toad will tell you\
further down there.\
We need more Silver\
Stars to be able to\
travel further, Mario.\
The engine will require\
12 more Silver Stars\
so we can move\
further.\
When you get 12 Silver\
Stars, come back and\
enter the engine room\
to move on."))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("Hello Mario!\
Let me explain\
what's\
going on...\
You see...\
There is a very\
powerful star...\
It's NOT a power\
star...\
But a different type.\
It is called\
The Galactic Star.\
This star holds\
the universe together.\
It controls movements\
of planets, activity\
of space in all ways...\
It balances them...\
It was in the center\
of the universe...\
Bowser has stolen the\
Galactic Star!\
He intends to use\
it for his evil\
purposes...\
The Galactic Star also\
has control over\
Silver Stars. Each\
space zone has silver\
stars, even our zone\
and planet...\
As the Galactic Star\
left its slot in the\
altar, Silver Stars\
were zoomed out through\
space from all the zones.\
Unfortunately, when\
the Lumas built this\
ship, they set its engine\
to Silver Star Energy.\
That was before\
the Silver Stars \
of our planet reacted\
to The Galactic Star's\
absence."))

smlua_text_utils_dialog_replace(DIALOG_136,1,6,30,200, ("Hey there.\
You see these\
cannons...\
Those can blast you\
to areas in space\
that you can search\
for Silver Stars.\
Each cannon will\
blast you to  certain\
area. Just jump into\
the red entrance of\
the cannon you\
please and you will\
be automatically\
blasted to the area\
each cannon can blast\
you off to."))

smlua_text_utils_dialog_replace(DIALOG_137,1,6,30,200, ("The teleporter is turned\
off now as well as\
the cannons.\
That's the case since\
there is no place that\
the cannons can blast you\
off to.\
The captain is up front by\
the bridge the Starship\
extended so we can cross. "))

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, ("Down: Underground Lake\
Left: Black Hole\
Right: Hazy Maze (Closed)"))

smlua_text_utils_dialog_replace(DIALOG_139,1,6,30,200, ("Above: Automatic Elevator\
Elevator begins\
automatically and follows\
pre-set course.\
It disappears\
automatically, too."))

smlua_text_utils_dialog_replace(DIALOG_140,1,6,30,200, ("Elevator Area\
Right: Hazy Maze\
/// Entrance\
Left: Black Hole\
///Elevator 1\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_141,1,5,150,200, ("  "))

smlua_text_utils_dialog_replace(DIALOG_142,1,5,150,200, ("  "))

smlua_text_utils_dialog_replace(DIALOG_143,1,6,150,200, ("  "))

smlua_text_utils_dialog_replace(DIALOG_144,1,6,150,200, ("  "))

smlua_text_utils_dialog_replace(DIALOG_145,1,6,150,200, ("  "))

smlua_text_utils_dialog_replace(DIALOG_146,1,6,150,200, ("  "))

smlua_text_utils_dialog_replace(DIALOG_147,1,5,30,200, ("In this block is\
the vanish cap.\
You can use it\
to go through some\
cages or so...\
If it is not solid,\
probably you did not\
activate it yet.\
\
It is said there is\
a magic warp leading to\
the area that has\
the vanish cap switch\
hidden in these fields.\
It is also said that\
the magic warp is\
in a hole...\
"))

smlua_text_utils_dialog_replace(DIALOG_148,1,6,30,200, ("Snowman Mountain ahead.\
Keep out! And don't try\
the Triple Jump over the\
ice block shooter.\
\
\
If you fall into the\
freezing pond, your power\
decreases quickly, and\
you won't recover\
automatically.\
//--The Snowman"))

smlua_text_utils_dialog_replace(DIALOG_149,1,3,30,200, ("Welcome to\
Princess Toadstool's\
secret slide!\
There's a Star hidden\
here that Bowser couldn't\
find.\
When you slide, press\
forward to speed up,\
pull back to slow down.\
If you slide really\
fast, you'll win the Star!"))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, ("Well well... If it isn't\
Mario! So we meet again!\
You thought you defeated\
me for good our last\
encounter, huh?!\
Well don't think too\
long... For I have\
returned and this time,\
you will suffer!\
Prepare for defeat,\
Mario!"))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, ("Ugghh...\
Mario!\
It's been a while!\
I still remember\
the humiliation\
you brought me in\
Apocal Valley a few\
years ago...\
Don't think I forgot!\
You may have stomped\
me then...\
But this time, I'll\
be the one to stomp\
you!\
"))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, ("Ouch... My head...\
It hurts...\
Defeated again...\
Hear me out, Mario...\
I will return and I will\
get my revenge! I assure\
you of that!\
As for now, farewell..."))

smlua_text_utils_dialog_replace(DIALOG_153,1,4,30,200, ("Hey! Who's there?\
What's climbing on me?\
Is it an ice ant?\
A snow flea?\
Whatever it is, it's\
bugging me! I think I'll\
blow it away!"))

smlua_text_utils_dialog_replace(DIALOG_154,1,5,30,200, ("You know, it still\
creeps me the sight\
of that portal opening.\
Make sure our friend is\
ok and try using\
the Star energy to get\
him back, Mario.\
Good luck!"))

smlua_text_utils_dialog_replace(DIALOG_155,1,6,30,200, ("It's interesting that\
one of Bowser's troops\
is obviously disloyal...\
I wonder if he took\
over Bowser's troops\
as well...\
Looks like Bowser wants\
revenge on that traitor\
so that he gave this\
Silver Star to us, huh?!"))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("Hey, I forgot to ask you.\
Did you run into Bowser?\
I saw him pass by here.\
I heard him saying\
one of his followers\
betrayed him and stole\
his master plan!\
Well...\
That was unexpected..."))

smlua_text_utils_dialog_replace(DIALOG_157,1,5,30,200, ("Watch out! Don't let\
yourself be swallowed by\
quicksand.\
\
\
If you sink into the sand,\
you won't be able to\
jump, and if your head\
goes under, you'll be\
smothered.\
The dark areas are\
bottomless pits."))

smlua_text_utils_dialog_replace(DIALOG_158,1,6,30,200, ("1. If you jump repeatedly\
and time it right, you'll\
jump higher and higher.\
If you run really fast and\
time three jumps right,\
you can do a Triple Jump.\
2. Jump into a solid wall,\
then jump again when you\
hit the wall. You can\
bounce to a higher level\
using this Wall Kick."))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("3. If you stop, press [Z]\
to crouch, then jump, you\
can perform a Backward\
Somersault. To do a Long\
Jump, run fast, press [Z],\
then jump."))

smlua_text_utils_dialog_replace(DIALOG_160,1,4,30,200, ("Press [B] while running\
fast to do a Body Slide\
attack. To stand while\
sliding, press [A] or [B]."))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("Mario!!!\
It that really you???\
It has been so long since\
our last adventure!\
They told me that I might\
see you if I waited here,\
but I'd just about given\
up hope!\
Is it true? Have you\
really beaten Bowser? And\
restored the Stars to the\
castle?\
And saved the Princess?\
I knew you could do it!\
Now I have a very special\
message for you.\
『Thanks for playing Super\
Mario 64! This is the\
end of the game, but not\
the end of the fun.\
We want you to keep on\
playing, so we have a\
little something for you.\
We hope that you like it!\
Enjoy!!!』\
\
The Super Mario 64 Team"))

smlua_text_utils_dialog_replace(DIALOG_162,1,4,30,200, ("Ouch! You again?!\
How do you know\
I even have a Silver \
Star this time?!\
Ouch! Ok, ok, I do!\
Take it then and leave\
me alone!!!"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("Noooo! You've really\
beaten me this time,\
Mario! I can't stand\
losing to you!\
\
My troops...worthless!\
They've turned over all\
the Power Stars! What?!\
There are 120 in all???\
\
Amazing! There were some\
in the castle that I\
missed??!!\
\
\
Now I see peace\
returning to the world...\
Oooo! I really hate that!\
I can't watch--\
I'm outta here!\
Just you wait until next\
time. Until then, keep\
that Control Stick\
smokin'!\
Buwaa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, ("Mario! What's up, pal?\
I haven't been on the\
slide lately, so I'm out\
of shape.\
Still, I'm always up for a\
good race, especially\
against an old sleddin'\
buddy.\
Whaddya say?\
Ready...set...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, ("I take no responsibility\
whatsoever for those who\
get dizzy and pass out\
from running around\
this post."))

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, ("I'll be back soon.\
I'm out training now,\
so come back later.\
//--Koopa the Quick"))

smlua_text_utils_dialog_replace(DIALOG_167,1,4,30,200, ("Princess Toadstool's\
castle is just ahead.\
\
\
Press [A] to jump, [Z] to\
crouch, and [B] to punch,\
read a sign, or grab\
something.\
Press [B] again to throw\
something you're holding."))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, ("Waahhh...\
You little pest!\
Not this time, Mario!\
Let's see you beat me\
now!\
Hi-yaaaaa...!!!"))

smlua_text_utils_dialog_replace(DIALOG_169,1,4,30,200, ("Keep out!\
That means you!\
Arrgghh!\
\
Anyone entering this cave\
without permission will\
meet certain disaster."))

